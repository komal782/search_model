package Facts;

/**
 * Created by shado on 12/1/2016.
 */
public interface ConstraintID {

    public final int SOFTCONSTRAINT1 = 0;
    public final int SOFTCONSTRAINT2 = 1;
    public final int SOFTCONSTRAINT3 = 2;
    public final int SOFTCONSTRAINT4 = 3;
    public final int SOFTCONSTRAINT5 = 4;
    public final int SOFTCONSTRAINT6 = 5;
    public final int SOFTCONSTRAINT7 = 6;
    public final int SOFTCONSTRAINT8 = 7;
    public final int SOFTCONSTRAINT9 = 8;
    public final int SOFTCONSTRAINT10 = 9;
    public final int SOFTCONSTRAINT11 = 10;
    public final int SOFTCONSTRAINT12 = 11;
    public final int SOFTCONSTRAINT13 = 12;
    public final int SOFTCONSTRAINT14 = 13;
    public final int SOFTCONSTRAINT15 = 14;
    public final int SOFTCONSTRAINT16 = 15;




}
