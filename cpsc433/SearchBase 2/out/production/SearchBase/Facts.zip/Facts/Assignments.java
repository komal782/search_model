package Facts;

import SetBased.Tuple;

import java.util.*;
import java.util.Comparator;
/**
 * Created by shado on 11/30/2016.
 */
public class Assignments implements ConstraintID {

    private static Comparator<Assignment> comparator = new Comparator<Assignment>(){
        @Override
        public int compare(Assignment o1, Assignment o2) {
            return Integer.min(o1.getScore(), o2.getScore());
        }
    };
    private PriorityQueue<Assignment> assignmentPriorityQueue;
    private ArrayList<Assignment> assignments;
    private Tuple<Integer,Integer> violationSoftContsraint;

    private int score;
    public Assignments(int score){
        assignmentPriorityQueue = new PriorityQueue<>(comparator);
        this.score = score;
        assignments = new ArrayList<>();
    }
    public void clearPriorityQueue(){
        assignmentPriorityQueue.clear();
    }
    public void addToPriorityQueue(Assignment assignment){
        assignmentPriorityQueue.add(assignment);
    }
    public int getScore(){
        return score;
    }
    public void setScore(int score){
        this.score = score;
    }
    public ArrayList<Assignment> getAssignments(){
        return new ArrayList<Assignment>(assignments);
    }
    public void setAssignments(ArrayList<Assignment> assignments){
        this.assignments = new ArrayList<>(assignments);
    }



}
