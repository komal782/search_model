package Facts;

/**
 * Created by Brandon on 11/24/2016.
 */
public class Assignment implements ConstraintID {

    private Room room;
    private Person person1;
    private Person person2;
    private int score;
    private int softConstaintViolated = -1;

    public Assignment(Room room, Person person){
        this.room = room;
        this.person1 = person;
    }

    public Room getRoom(){
        return room;
    }
    public Person[] getPerson(){
        if(person2 != null)
            return new Person[]{person1,person2};
        else
            return new Person[]{person1};
    }
    public int getScore(){
        return score;
    }


    public void setScore(int score){this.score = score;}
    public void addSecondPerson(Person person){
        this.person2 = person;
    }

    public int getSoftContraint(){
        return this.softConstaintViolated;
    }
    public void setSoftContraint(int softConstaintViolated){
        this.softConstaintViolated = softConstaintViolated;
    }

}
