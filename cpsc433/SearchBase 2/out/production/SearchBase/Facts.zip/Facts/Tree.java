package Facts;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.function.Function;

import Facts.*;
/**
 * Created by shado on 11/24/2016.
 */
public class Tree extends Violations {

    public Tree(){

    }
    /**
     * for noe the or Tree is build randomly, while avoiding violating hard contraints.
     * Note we are assigning persons rooms (rooms to persons)
     *
     * will try to satisfy manager having large room soft contraint
     */

    public static ArrayDeque<Room> buildTree(ArrayDeque<Room> rooms, ArrayDeque<Person> persons){
        Environment environment = Environment.get();
        //Take a person
        //Take a room
        if(!persons.isEmpty()){
            Room room = rooms.remove();
            Person person = persons.remove();
            person.setRoomName(room.getName());

            if(persons.isEmpty() || person.isGroupHead || person.isManager || person.projectHead){

                Assignment temp = new Assignment(room,person);
                environment.setAssignment(temp);
            }
            else {
                Person person2 = persons.element();
                if(!person2.isGroupHead || !person2.isManager || !person2.projectHead){
                    persons.remove();
                    person2.setRoomName(room.getName());
                    Assignment temp = new Assignment(room, person);
                    temp.addSecondPerson(person2);
                    environment.setAssignment(temp);
                }
            }


            buildTree(rooms, persons);


        }
        return rooms;


    }



}
